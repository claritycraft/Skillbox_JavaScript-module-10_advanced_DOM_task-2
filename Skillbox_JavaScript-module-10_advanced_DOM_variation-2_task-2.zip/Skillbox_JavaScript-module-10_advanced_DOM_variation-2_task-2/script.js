const buttonAddEl = document.querySelector(".buttonadd");
const buttonDeleteEl = document.querySelector(".buttondelite");

buttonAddEl.addEventListener("click", () => {
  const listEl = document.getElementById("list");
  const liEl = document.createElement("li");
  liEl.textContent = "Новый элемент списка";
  listEl.appendChild(liEl);
});

buttonDeleteEl.addEventListener("click", () => {
  const listEl = document.getElementById("list");
  const listItem = listEl.lastElementChild;

  if (listItem) {
    listItem.remove();
    //   listEl.removeChild(lastItem)
  }
});
