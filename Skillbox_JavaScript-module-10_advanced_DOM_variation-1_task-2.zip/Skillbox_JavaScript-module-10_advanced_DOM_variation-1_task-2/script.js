document.getElementById("addButton").addEventListener("click", function () {
  let li = document.createElement("li");
  li.textContent = "Новый элемент списка";
  document.getElementById("list").appendChild(li);
});

document.getElementById("removeButton").addEventListener("click", function () {
  let list = document.getElementById("list");
  if (list.lastChild) {
    list.removeChild(list.lastChild);
  }
});
